import{e}from"./index-DTScpf0N.js";e();
